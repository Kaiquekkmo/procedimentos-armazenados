# procedimentos-armazenados
Template para o exercício de procedimentos armazenados
